AppGini.Calendar.language = AppGini.Calendar.language || {};
AppGini.Calendar.language.en = $j.extend(AppGini.Calendar.language.en, {
	please_wait: 'PLease wait ...',
	new_x: 'New %event%',


	/*************************************************************/
	end_place_holder: '--- Please keep this line at the end of the file! ---'
})